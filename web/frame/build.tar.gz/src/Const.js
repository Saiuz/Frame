const serverURL = "http://35.230.80.120:8080"
export default serverURL;